-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg06.eigbox.net
-- Generation Time: Aug 04, 2012 at 11:21 AM
-- Server version: 5.0.91
-- PHP Version: 4.4.9
-- 
-- Database: `shoplongdestiny`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `adminusers`
-- 

CREATE TABLE `adminusers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `adminusers`
-- 

INSERT INTO `adminusers` VALUES (1, 'admin', 'Pineapple01');

-- --------------------------------------------------------

-- 
-- Table structure for table `carousel`
-- 

CREATE TABLE `carousel` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `imgname` varchar(255) NOT NULL,
  `desc` varchar(255) default NULL,
  `price` decimal(8,2) default NULL,
  `position` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `carousel`
-- 

INSERT INTO `carousel` VALUES (11, 'rukawa', '1001e63a6afdccf66c14c09f4a238298.jpg', 'Slam Dunk Rukawa!', 0.00, 1);
INSERT INTO `carousel` VALUES (12, 'Bleach', '3d053d02030d8b41900cbbfb5e64c7f4.jpg', '', 0.00, 11);
INSERT INTO `carousel` VALUES (13, 'Natsu vs Gray', 'f8ae9efdd7655bfcd36b1e18cf20c35f.jpg', '', 19.99, 5);

-- --------------------------------------------------------

-- 
-- Table structure for table `orders`
-- 

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `qty` int(5) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY  (`oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `orders`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `pid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `desc` longtext NOT NULL,
  `img1` varchar(255) default NULL,
  `price` float NOT NULL,
  `category` varchar(100) NOT NULL,
  `sub_cat` varchar(100) NOT NULL,
  `img2` varchar(255) default NULL,
  `img3` varchar(255) default NULL,
  `img4` varchar(255) default NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `products`
-- 

INSERT INTO `products` VALUES (11, 'Sony Xperia U', 'sony smartphone', 'katekyo-hitman-reborn-picture_1024x768_43931.jpg', 19.99, 'Sony', 'Phones', 'fairy012.jpg', 'fairy022.jpg', 'gacchan02.jpg');
INSERT INTO `products` VALUES (6, 'lumia 900', 'nokia smartphone', 'a5db8295c34bd4fb47c20b13e68a57de.png', 9.99, 'Nokia', 'Smartphones', NULL, NULL, NULL);
INSERT INTO `products` VALUES (8, 'iphone 3gs', 'iphone', '2891c4c80de49238b55f25b6ec2f2c8c.jpg', 99, 'apple', 'phones', 'bleach01.png', 'aboutme01.jpg', 'fairy013.jpg');
INSERT INTO `products` VALUES (10, 'death note shirt', 'top rated shirt', 'logo.png', 19.99, 't-shirts', 'tokyo', NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `uid` int(11) NOT NULL auto_increment,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) default NULL,
  `postcode` varchar(30) NOT NULL,
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 'andy', 'lastname', 'andy@yahoo.com', 'Password1', '', '', '');
INSERT INTO `users` VALUES (2, 'peter', 'parker', 'peter@hotmail.com', 'password', '', '', '');
INSERT INTO `users` VALUES (3, 'Konyau', 'wong', 'konyau@hotmail.com', 'Password', '', NULL, '');
